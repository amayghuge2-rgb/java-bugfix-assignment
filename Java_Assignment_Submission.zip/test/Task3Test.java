import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class Task3Test {

    @Test
    public void testProcessedCount() {
        Task3 processor = new Task3();

        List<StatementRecord> records = Arrays.asList(
            new StatementRecord(),
            new StatementRecord()
        );

        processor.process(records);
        assertEquals(2, processor.getProcessedCount());
    }
}
